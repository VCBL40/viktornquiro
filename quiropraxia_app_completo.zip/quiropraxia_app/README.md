# Sistema de Agendamento para Quiropraxia

## Descrição

Este é um sistema web completo para agendamento de sessões de quiropraxia com atendimento domiciliar. O sistema permite que clientes se cadastrem uma única vez e depois façam agendamentos de forma simplificada, sem necessidade de login.

## Características Principais

### Funcionalidades para Clientes

- **Cadastro Simplificado**: Cliente novo preenche um formulário completo apenas uma vez
- **Reconhecimento Automático**: Cliente que já existe no sistema é reconhecido pelo nome
- **Agendamento Rápido**: Clientes cadastrados vão direto para a tela de agendamento
- **Sem Login**: Sistema sem necessidade de senha ou autenticação

### Dados Coletados

O sistema coleta e armazena as seguintes informações dos clientes:

1. **Nome Completo** (obrigatório)
2. **Idade**
3. **Histórico de Saúde**
4. **Queixa Principal**
5. **Endereço Residencial** (obrigatório) - para atendimento domiciliar

### Tecnologias Utilizadas

**Backend:**
- Python 3.11
- Flask (framework web)
- SQLite (banco de dados)
- Flask-CORS (para comunicação com frontend)

**Frontend:**
- React 18
- Vite (build tool)
- Tailwind CSS (estilização)
- shadcn/ui (componentes UI)
- Lucide React (ícones)

## Estrutura do Projeto

```
quiropraxia_app/
├── backend/
│   ├── src/
│   │   └── main.py          # Aplicação Flask principal
│   ├── static/              # Arquivos do frontend compilado
│   ├── venv/                # Ambiente virtual Python
│   ├── requirements.txt     # Dependências Python
│   └── quiropraxia.db      # Banco de dados SQLite
└── frontend/
    ├── src/
    │   ├── App.jsx          # Componente principal React
    │   └── App.css          # Estilos
    ├── dist/                # Build de produção
    └── package.json         # Dependências Node.js
```

## Banco de Dados

O sistema utiliza SQLite com duas tabelas principais:

### Tabela: clientes

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | INTEGER | Chave primária (auto-incremento) |
| nome | TEXT | Nome completo do cliente |
| idade | INTEGER | Idade do cliente |
| historico_saude | TEXT | Histórico médico relevante |
| queixa_principal | TEXT | Queixa ou motivo da consulta |
| endereco_residencial | TEXT | Endereço completo para atendimento |
| data_cadastro | TIMESTAMP | Data e hora do cadastro |

### Tabela: agendamentos

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | INTEGER | Chave primária (auto-incremento) |
| cliente_id | INTEGER | Referência ao cliente |
| data_agendamento | DATE | Data da sessão |
| hora_agendamento | TIME | Horário da sessão |
| status | TEXT | Status do agendamento (padrão: 'pendente') |
| data_criacao | TIMESTAMP | Data e hora da criação do agendamento |

## API Endpoints

### Clientes

**POST /api/clientes**
- Cadastra um novo cliente
- Body: `{ nome, idade, historico_saude, queixa_principal, endereco_residencial }`
- Retorna: `{ message, cliente_id }`

**GET /api/clientes/buscar?nome={nome}**
- Busca um cliente pelo nome
- Retorna: Dados completos do cliente ou mensagem de não encontrado

### Agendamentos

**POST /api/agendamentos**
- Cria um novo agendamento
- Body: `{ cliente_id, data_agendamento, hora_agendamento }`
- Retorna: `{ message, agendamento_id }`

**GET /api/agendamentos?cliente_id={id}**
- Lista agendamentos (opcionalmente filtrado por cliente)
- Retorna: Array de agendamentos

**GET /api/agendamentos/disponiveis?data={data}**
- Lista horários disponíveis para agendamento
- Retorna: `{ data, horarios_disponiveis }`

## Como Executar

### Pré-requisitos

- Python 3.11+
- Node.js 22+
- pnpm

### Instalação

1. **Backend:**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

2. **Frontend (para desenvolvimento):**
```bash
cd frontend
pnpm install
```

### Executar em Desenvolvimento

**Backend:**
```bash
cd backend
source venv/bin/activate
python3 src/main.py
```
O servidor estará disponível em `http://localhost:5000`

**Frontend (separado):**
```bash
cd frontend
pnpm run dev
```
O frontend estará disponível em `http://localhost:5173`

### Executar em Produção

O backend já serve os arquivos estáticos do frontend compilado:

```bash
cd backend
source venv/bin/activate
python3 src/main.py
```

Acesse em `http://localhost:5000`

## Fluxo de Uso

### Para Cliente Novo

1. Cliente acessa o sistema
2. Digite seu nome no campo de busca
3. Sistema não encontra o cadastro
4. Cliente preenche formulário completo com:
   - Nome completo
   - Idade
   - Histórico de saúde
   - Queixa principal
   - Endereço residencial
5. Cliente escolhe data e hora para a sessão
6. Agendamento é confirmado

### Para Cliente Existente

1. Cliente acessa o sistema
2. Digite seu nome no campo de busca
3. Sistema reconhece o cliente e exibe seus dados
4. Cliente vai direto para tela de agendamento
5. Cliente escolhe data e hora para a sessão
6. Agendamento é confirmado

## Acesso ao Banco de Dados

Para visualizar os dados armazenados, você pode usar Python:

```python
import sqlite3

conn = sqlite3.connect('backend/quiropraxia.db')
cursor = conn.cursor()

# Ver todos os clientes
cursor.execute('SELECT * FROM clientes')
for row in cursor.fetchall():
    print(row)

# Ver todos os agendamentos
cursor.execute('SELECT * FROM agendamentos')
for row in cursor.fetchall():
    print(row)

conn.close()
```

Ou use ferramentas como:
- DB Browser for SQLite
- DBeaver
- Qualquer cliente SQLite

## Personalização

### Horários Disponíveis

Os horários disponíveis estão definidos no arquivo `backend/src/main.py` na função `get_available_slots()`. Atualmente são:

- 09:00
- 10:00
- 11:00
- 14:00
- 15:00
- 16:00

Para modificar, edite a lista `available_times` no código.

### Estilização

O frontend usa Tailwind CSS. Para personalizar cores e estilos, edite:
- `frontend/src/App.jsx` - Componentes e estrutura
- `frontend/src/App.css` - Estilos customizados
- `frontend/tailwind.config.js` - Configuração do Tailwind

## Segurança e Considerações

- O banco de dados SQLite é adequado para uso local ou pequena escala
- Para produção em larga escala, considere migrar para PostgreSQL ou MySQL
- Adicione validação de dados mais robusta conforme necessário
- Implemente backup regular do banco de dados
- Considere adicionar autenticação para área administrativa

## Próximas Melhorias Sugeridas

1. **Área Administrativa**: Painel para o quiropraxista visualizar e gerenciar agendamentos
2. **Notificações**: Envio de lembretes por email ou SMS
3. **Cancelamento**: Permitir que clientes cancelem agendamentos
4. **Histórico**: Visualização do histórico de sessões do cliente
5. **Disponibilidade Real**: Sistema inteligente que verifica horários já ocupados
6. **Relatórios**: Geração de relatórios de atendimentos e estatísticas

## Suporte

Para dúvidas ou problemas, consulte a documentação ou entre em contato.

---

**Desenvolvido para facilitar o agendamento de sessões de quiropraxia domiciliar.**

