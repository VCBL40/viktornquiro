from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import sqlite3
from datetime import datetime

# Obter o diretório base do projeto
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE = os.path.join(BASE_DIR, 'quiropraxia.db')

app = Flask(__name__, static_folder='../static', static_url_path='')
CORS(app)  # Habilita CORS para todas as rotas

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # Retorna linhas como dicionários
    return conn

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                idade INTEGER,
                historico_saude TEXT,
                queixa_principal TEXT,
                endereco_residencial TEXT,
                data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS agendamentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id INTEGER NOT NULL,
                data_agendamento DATE NOT NULL,
                hora_agendamento TIME NOT NULL,
                status TEXT DEFAULT 'pendente',
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (cliente_id) REFERENCES clientes (id)
            )
        ''')
        db.commit()
        db.close()

# Inicializa o banco de dados na primeira execução
with app.app_context():
    init_db()

# Rota principal - serve o index.html
@app.route('/')
def index():
    return app.send_static_file('index.html')

# Rota catch-all para o React Router
@app.route('/<path:path>')
def catch_all(path):
    # Se o arquivo existe, serve ele
    if os.path.exists(os.path.join(app.static_folder, path)):
        return app.send_static_file(path)
    # Senão, serve o index.html (para rotas do React)
    return app.send_static_file('index.html')

@app.route('/api')
def api_info():
    return 'Bem-vindo à API de Agendamentos de Quiropraxia!'

# Endpoint para cadastrar um novo cliente
@app.route('/api/clientes', methods=['POST'])
def add_cliente():
    data = request.get_json()
    nome = data.get('nome')
    idade = data.get('idade')
    historico_saude = data.get('historico_saude')
    queixa_principal = data.get('queixa_principal')
    endereco_residencial = data.get('endereco_residencial')

    if not nome or not endereco_residencial:
        return jsonify({'error': 'Nome e endereço residencial são obrigatórios'}), 400

    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute(
            "INSERT INTO clientes (nome, idade, historico_saude, queixa_principal, endereco_residencial) VALUES (?, ?, ?, ?, ?)",
            (nome, idade, historico_saude, queixa_principal, endereco_residencial)
        )
        db.commit()
        cliente_id = cursor.lastrowid
        return jsonify({'message': 'Cliente cadastrado com sucesso', 'cliente_id': cliente_id}), 201
    except sqlite3.IntegrityError as e:
        return jsonify({'error': f'Erro ao cadastrar cliente: {e}'}), 500
    finally:
        db.close()

# Endpoint para buscar um cliente pelo nome
@app.route('/api/clientes/buscar', methods=['GET'])
def search_cliente():
    nome_busca = request.args.get('nome')
    if not nome_busca:
        return jsonify({'error': 'Parâmetro nome é obrigatório para busca'}), 400

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM clientes WHERE nome LIKE ?", (f'%{nome_busca}%',))
    cliente = cursor.fetchone()
    db.close()

    if cliente:
        return jsonify(dict(cliente)), 200
    else:
        return jsonify({'message': 'Cliente não encontrado'}), 404

# Endpoint para criar um novo agendamento
@app.route('/api/agendamentos', methods=['POST'])
def add_agendamento():
    data = request.get_json()
    cliente_id = data.get('cliente_id')
    data_agendamento_str = data.get('data_agendamento')
    hora_agendamento_str = data.get('hora_agendamento')

    if not cliente_id or not data_agendamento_str or not hora_agendamento_str:
        return jsonify({'error': 'cliente_id, data_agendamento e hora_agendamento são obrigatórios'}), 400

    try:
        # Valida formato da data e hora
        datetime.strptime(data_agendamento_str, '%Y-%m-%d').date()
        datetime.strptime(hora_agendamento_str, '%H:%M').time()
    except ValueError:
        return jsonify({'error': 'Formato de data (AAAA-MM-DD) ou hora (HH:MM) inválido'}), 400

    db = get_db()
    cursor = db.cursor()
    try:
        # Verifica se o cliente existe
        cursor.execute("SELECT id FROM clientes WHERE id = ?", (cliente_id,))
        if not cursor.fetchone():
            return jsonify({'error': 'Cliente não encontrado'}), 404

        cursor.execute(
            "INSERT INTO agendamentos (cliente_id, data_agendamento, hora_agendamento) VALUES (?, ?, ?)",
            (cliente_id, data_agendamento_str, hora_agendamento_str)
        )
        db.commit()
        agendamento_id = cursor.lastrowid
        return jsonify({'message': 'Agendamento criado com sucesso', 'agendamento_id': agendamento_id}), 201
    except sqlite3.IntegrityError as e:
        return jsonify({'error': f'Erro ao criar agendamento: {e}'}), 500
    finally:
        db.close()

# Endpoint para listar agendamentos (opcionalmente por cliente)
@app.route('/api/agendamentos', methods=['GET'])
def get_agendamentos():
    cliente_id = request.args.get('cliente_id')
    db = get_db()
    cursor = db.cursor()
    if cliente_id:
        cursor.execute("SELECT * FROM agendamentos WHERE cliente_id = ?", (cliente_id,))
    else:
        cursor.execute("SELECT * FROM agendamentos")
    agendamentos = cursor.fetchall()
    db.close()
    return jsonify([dict(row) for row in agendamentos]), 200

# Endpoint para listar horários disponíveis (simulado por enquanto)
@app.route('/api/agendamentos/disponiveis', methods=['GET'])
def get_available_slots():
    # Por simplicidade, vamos simular alguns horários disponíveis
    # Em uma aplicação real, isso envolveria lógica mais complexa
    # verificando agendamentos existentes e a agenda do quiropraxista.
    data_str = request.args.get('data', datetime.now().strftime('%Y-%m-%d'))
    
    # Exemplo de horários fixos para demonstração
    available_times = [
        "09:00", "10:00", "11:00", "14:00", "15:00", "16:00"
    ]
    
    # Em um cenário real, você buscaria agendamentos para `data_str`
    # e removeria os horários já ocupados de `available_times`.
    
    return jsonify({'data': data_str, 'horarios_disponiveis': available_times}), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

