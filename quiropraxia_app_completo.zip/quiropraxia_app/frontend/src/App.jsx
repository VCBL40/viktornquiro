import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Calendar, User, Clock } from 'lucide-react'
import './App.css'

function App() {
  const [step, setStep] = useState('busca') // 'busca', 'cadastro', 'agendamento', 'confirmacao'
  const [cliente, setCliente] = useState(null)
  const [nomeBusca, setNomeBusca] = useState('')
  const [loading, setLoading] = useState(false)

  // Dados do formulário de cadastro
  const [formData, setFormData] = useState({
    nome: '',
    idade: '',
    historico_saude: '',
    queixa_principal: '',
    endereco_residencial: ''
  })

  // Dados do agendamento
  const [agendamento, setAgendamento] = useState({
    data: '',
    hora: ''
  })

  const API_URL = '/api'

  const handleBuscarCliente = async () => {
    if (!nomeBusca.trim()) {
      alert('Por favor, digite seu nome')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/clientes/buscar?nome=${encodeURIComponent(nomeBusca)}`)
      const data = await response.json()

      if (response.ok && data.id) {
        setCliente(data)
        setStep('agendamento')
      } else {
        // Cliente não encontrado, ir para cadastro
        setFormData({ ...formData, nome: nomeBusca })
        setStep('cadastro')
      }
    } catch (error) {
      console.error('Erro ao buscar cliente:', error)
      alert('Erro ao buscar cliente. Verifique se o servidor está rodando.')
    } finally {
      setLoading(false)
    }
  }

  const handleCadastrarCliente = async (e) => {
    e.preventDefault()
    
    if (!formData.nome || !formData.endereco_residencial) {
      alert('Nome e endereço são obrigatórios')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/clientes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      })

      const data = await response.json()

      if (response.ok) {
        setCliente({ ...formData, id: data.cliente_id })
        setStep('agendamento')
      } else {
        alert(data.error || 'Erro ao cadastrar cliente')
      }
    } catch (error) {
      console.error('Erro ao cadastrar cliente:', error)
      alert('Erro ao cadastrar cliente. Verifique se o servidor está rodando.')
    } finally {
      setLoading(false)
    }
  }

  const handleAgendarSessao = async (e) => {
    e.preventDefault()

    if (!agendamento.data || !agendamento.hora) {
      alert('Por favor, selecione data e hora')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/agendamentos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          cliente_id: cliente.id,
          data_agendamento: agendamento.data,
          hora_agendamento: agendamento.hora
        })
      })

      const data = await response.json()

      if (response.ok) {
        setStep('confirmacao')
      } else {
        alert(data.error || 'Erro ao criar agendamento')
      }
    } catch (error) {
      console.error('Erro ao criar agendamento:', error)
      alert('Erro ao criar agendamento. Verifique se o servidor está rodando.')
    } finally {
      setLoading(false)
    }
  }

  const resetarApp = () => {
    setStep('busca')
    setCliente(null)
    setNomeBusca('')
    setFormData({
      nome: '',
      idade: '',
      historico_saude: '',
      queixa_principal: '',
      endereco_residencial: ''
    })
    setAgendamento({
      data: '',
      hora: ''
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Cabeçalho */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Quiropraxia</h1>
          <p className="text-gray-600">Agendamento de Sessões</p>
        </div>

        {/* Etapa 1: Busca de Cliente */}
        {step === 'busca' && (
          <Card className="shadow-xl animate-fade-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-6 h-6" />
                Bem-vindo!
              </CardTitle>
              <CardDescription>
                Digite seu nome para verificar se você já é nosso cliente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="nome-busca">Nome Completo</Label>
                  <Input
                    id="nome-busca"
                    type="text"
                    placeholder="Digite seu nome"
                    value={nomeBusca}
                    onChange={(e) => setNomeBusca(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleBuscarCliente()}
                    className="mt-1"
                  />
                </div>
                <Button 
                  onClick={handleBuscarCliente} 
                  disabled={loading}
                  className="w-full"
                >
                  {loading ? 'Buscando...' : 'Continuar'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Etapa 2: Cadastro de Novo Cliente */}
        {step === 'cadastro' && (
          <Card className="shadow-xl animate-fade-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-6 h-6" />
                Cadastro de Novo Cliente
              </CardTitle>
              <CardDescription>
                Preencha suas informações para criar seu cadastro
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCadastrarCliente} className="space-y-4">
                <div>
                  <Label htmlFor="nome">Nome Completo *</Label>
                  <Input
                    id="nome"
                    type="text"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="idade">Idade</Label>
                  <Input
                    id="idade"
                    type="number"
                    value={formData.idade}
                    onChange={(e) => setFormData({ ...formData, idade: e.target.value })}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="historico">Histórico de Saúde</Label>
                  <Textarea
                    id="historico"
                    value={formData.historico_saude}
                    onChange={(e) => setFormData({ ...formData, historico_saude: e.target.value })}
                    placeholder="Descreva seu histórico médico relevante"
                    className="mt-1"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="queixa">Queixa Principal</Label>
                  <Textarea
                    id="queixa"
                    value={formData.queixa_principal}
                    onChange={(e) => setFormData({ ...formData, queixa_principal: e.target.value })}
                    placeholder="Descreva sua principal queixa"
                    className="mt-1"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="endereco">Endereço Residencial *</Label>
                  <Textarea
                    id="endereco"
                    value={formData.endereco_residencial}
                    onChange={(e) => setFormData({ ...formData, endereco_residencial: e.target.value })}
                    placeholder="Endereço completo para atendimento domiciliar"
                    required
                    className="mt-1"
                    rows={2}
                  />
                </div>

                <div className="flex gap-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={resetarApp}
                    className="flex-1"
                  >
                    Voltar
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={loading}
                    className="flex-1"
                  >
                    {loading ? 'Cadastrando...' : 'Cadastrar e Agendar'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Etapa 3: Agendamento */}
        {step === 'agendamento' && (
          <Card className="shadow-xl animate-fade-in">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-6 h-6" />
                Agendar Sessão
              </CardTitle>
              <CardDescription>
                Olá, {cliente?.nome}! Escolha a data e hora para sua sessão
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAgendarSessao} className="space-y-4">
                <div>
                  <Label htmlFor="data" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Data da Sessão
                  </Label>
                  <Input
                    id="data"
                    type="date"
                    value={agendamento.data}
                    onChange={(e) => setAgendamento({ ...agendamento, data: e.target.value })}
                    required
                    className="mt-1"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div>
                  <Label htmlFor="hora" className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Horário
                  </Label>
                  <Input
                    id="hora"
                    type="time"
                    value={agendamento.hora}
                    onChange={(e) => setAgendamento({ ...agendamento, hora: e.target.value })}
                    required
                    className="mt-1"
                  />
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-700">
                    <strong>Endereço:</strong> {cliente?.endereco_residencial}
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={resetarApp}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={loading}
                    className="flex-1"
                  >
                    {loading ? 'Agendando...' : 'Confirmar Agendamento'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Etapa 4: Confirmação */}
        {step === 'confirmacao' && (
          <Card className="shadow-xl animate-fade-in">
            <CardHeader>
              <CardTitle className="text-green-600">✓ Agendamento Confirmado!</CardTitle>
              <CardDescription>
                Sua sessão foi agendada com sucesso
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 p-4 rounded-lg space-y-2">
                <p className="text-sm">
                  <strong>Nome:</strong> {cliente?.nome}
                </p>
                <p className="text-sm">
                  <strong>Data:</strong> {new Date(agendamento.data + 'T00:00:00').toLocaleDateString('pt-BR')}
                </p>
                <p className="text-sm">
                  <strong>Horário:</strong> {agendamento.hora}
                </p>
                <p className="text-sm">
                  <strong>Endereço:</strong> {cliente?.endereco_residencial}
                </p>
              </div>

              <p className="text-sm text-gray-600">
                Aguardamos você no horário agendado. Em caso de necessidade de cancelamento ou reagendamento, entre em contato conosco.
              </p>

              <Button 
                onClick={resetarApp}
                className="w-full"
              >
                Fazer Novo Agendamento
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default App

