# Guia Rápido - Sistema de Agendamento Quiropraxia

## Como Iniciar o Sistema

### Opção 1: Executar Localmente (Recomendado)

1. **Abra o terminal** e navegue até a pasta do projeto:
```bash
cd /home/ubuntu/quiropraxia_app/backend
```

2. **Ative o ambiente virtual**:
```bash
source venv/bin/activate
```

3. **Inicie o servidor**:
```bash
python3 src/main.py
```

4. **Acesse no navegador**:
```
http://localhost:5000
```

### Opção 2: Usar URL Temporária

O sistema está temporariamente disponível em:
```
https://5000-ix9qwoljlii863bj3ko5z-0b9c0924.manus.computer
```

⚠️ **IMPORTANTE**: Esta URL é temporária e expira quando a sessão terminar. Para uso contínuo, execute localmente ou implante em um servidor próprio.

## Como Usar o Sistema

### Para Seus Clientes

1. **Acesse a URL** do sistema
2. **Digite o nome completo** no campo de busca
3. **Se for cliente novo**: Preencha todos os dados solicitados
4. **Se já for cadastrado**: Será reconhecido automaticamente
5. **Escolha data e hora** para a sessão
6. **Confirme o agendamento**

### Para Você (Quiropraxista)

#### Ver Todos os Clientes Cadastrados

```bash
cd /home/ubuntu/quiropraxia_app/backend
python3 -c "
import sqlite3
conn = sqlite3.connect('quiropraxia.db')
cursor = conn.cursor()
cursor.execute('SELECT id, nome, idade, endereco_residencial FROM clientes')
print('CLIENTES CADASTRADOS:')
print('-' * 80)
for row in cursor.fetchall():
    print(f'ID: {row[0]} | Nome: {row[1]} | Idade: {row[2]}')
    print(f'Endereço: {row[3]}')
    print('-' * 80)
conn.close()
"
```

#### Ver Todos os Agendamentos

```bash
cd /home/ubuntu/quiropraxia_app/backend
python3 -c "
import sqlite3
conn = sqlite3.connect('quiropraxia.db')
cursor = conn.cursor()
cursor.execute('''
    SELECT a.id, c.nome, a.data_agendamento, a.hora_agendamento, a.status, c.endereco_residencial
    FROM agendamentos a
    JOIN clientes c ON a.cliente_id = c.id
    ORDER BY a.data_agendamento, a.hora_agendamento
''')
print('AGENDAMENTOS:')
print('-' * 80)
for row in cursor.fetchall():
    print(f'ID: {row[0]} | Cliente: {row[1]}')
    print(f'Data: {row[2]} às {row[3]} | Status: {row[4]}')
    print(f'Endereço: {row[5]}')
    print('-' * 80)
conn.close()
"
```

#### Ver Agendamentos de Hoje

```bash
cd /home/ubuntu/quiropraxia_app/backend
python3 -c "
import sqlite3
from datetime import date
conn = sqlite3.connect('quiropraxia.db')
cursor = conn.cursor()
hoje = date.today().strftime('%Y-%m-%d')
cursor.execute('''
    SELECT c.nome, a.hora_agendamento, c.endereco_residencial, c.queixa_principal
    FROM agendamentos a
    JOIN clientes c ON a.cliente_id = c.id
    WHERE a.data_agendamento = ?
    ORDER BY a.hora_agendamento
''', (hoje,))
print(f'AGENDAMENTOS DE HOJE ({hoje}):')
print('-' * 80)
for row in cursor.fetchall():
    print(f'Horário: {row[1]} | Cliente: {row[0]}')
    print(f'Endereço: {row[2]}')
    print(f'Queixa: {row[3]}')
    print('-' * 80)
conn.close()
"
```

## Arquivos Importantes

### Banco de Dados
```
/home/ubuntu/quiropraxia_app/backend/quiropraxia.db
```
**⚠️ FAÇA BACKUP REGULAR DESTE ARQUIVO!** Ele contém todos os dados dos clientes e agendamentos.

### Código do Backend
```
/home/ubuntu/quiropraxia_app/backend/src/main.py
```

### Código do Frontend
```
/home/ubuntu/quiropraxia_app/frontend/src/App.jsx
```

## Backup do Banco de Dados

### Fazer Backup Manual

```bash
cp /home/ubuntu/quiropraxia_app/backend/quiropraxia.db /home/ubuntu/quiropraxia_app/backend/quiropraxia_backup_$(date +%Y%m%d_%H%M%S).db
```

### Restaurar Backup

```bash
cp /home/ubuntu/quiropraxia_app/backend/quiropraxia_backup_XXXXXXXX.db /home/ubuntu/quiropraxia_app/backend/quiropraxia.db
```

## Modificar Horários Disponíveis

1. Abra o arquivo:
```bash
nano /home/ubuntu/quiropraxia_app/backend/src/main.py
```

2. Procure pela função `get_available_slots()`

3. Modifique a lista `available_times`:
```python
available_times = [
    "09:00", "10:00", "11:00", "14:00", "15:00", "16:00"
]
```

4. Salve e reinicie o servidor

## Solução de Problemas

### Servidor não inicia

**Erro: "Address already in use"**
```bash
# Encontre o processo usando a porta 5000
lsof -i :5000

# Mate o processo (substitua PID pelo número encontrado)
kill -9 PID
```

### Banco de dados corrompido

```bash
# Restaure do backup mais recente
cp /home/ubuntu/quiropraxia_app/backend/quiropraxia_backup_XXXXXXXX.db /home/ubuntu/quiropraxia_app/backend/quiropraxia.db
```

### Página não carrega

1. Verifique se o servidor está rodando
2. Verifique se está acessando a URL correta
3. Limpe o cache do navegador (Ctrl+Shift+Del)

## Dicas de Uso

### Para Melhor Experiência

1. **Use em tablet ou computador** para facilitar o preenchimento dos formulários
2. **Oriente seus clientes** a digitarem o nome completo exatamente como cadastrado
3. **Faça backup diário** do banco de dados
4. **Revise os agendamentos** no início de cada dia

### Boas Práticas

- Confirme os agendamentos por telefone ou WhatsApp
- Mantenha o sistema rodando durante o horário comercial
- Atualize o status dos agendamentos após as sessões
- Exporte os dados regularmente para análise

## Próximos Passos

### Para Uso Profissional Contínuo

1. **Hospedagem**: Considere hospedar em:
   - Heroku (gratuito para pequeno uso)
   - DigitalOcean (a partir de $5/mês)
   - AWS, Google Cloud ou Azure

2. **Domínio Próprio**: Registre um domínio como:
   - `agendamento-quiropraxia.com.br`
   - `seunome-quiropraxia.com.br`

3. **Melhorias Futuras**:
   - Adicionar área administrativa
   - Implementar notificações automáticas
   - Permitir cancelamento de agendamentos
   - Gerar relatórios mensais

## Contato e Suporte

Para dúvidas sobre o funcionamento do sistema, consulte o arquivo `README.md` completo na pasta do projeto.

---

**Sistema pronto para uso! Bons atendimentos! 🙌**

