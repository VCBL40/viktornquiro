#!/usr/bin/env python3
"""
Script para visualizar dados do banco de dados do sistema de agendamento
Execute com: python3 ver_dados.py
"""

import sqlite3
import os
from datetime import date

# Caminho do banco de dados
DB_PATH = os.path.join(os.path.dirname(__file__), 'backend', 'quiropraxia.db')

def print_separator(char='=', length=80):
    print(char * length)

def ver_clientes():
    """Exibe todos os clientes cadastrados"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM clientes')
    total = cursor.fetchone()[0]
    
    print_separator()
    print(f"CLIENTES CADASTRADOS (Total: {total})")
    print_separator()
    
    if total == 0:
        print("Nenhum cliente cadastrado ainda.")
        conn.close()
        return
    
    cursor.execute('''
        SELECT id, nome, idade, historico_saude, queixa_principal, 
               endereco_residencial, data_cadastro 
        FROM clientes 
        ORDER BY data_cadastro DESC
    ''')
    
    for row in cursor.fetchall():
        print(f"\n📋 ID: {row[0]}")
        print(f"   Nome: {row[1]}")
        print(f"   Idade: {row[2] if row[2] else 'Não informada'}")
        print(f"   Histórico: {row[3] if row[3] else 'Não informado'}")
        print(f"   Queixa: {row[4] if row[4] else 'Não informada'}")
        print(f"   Endereço: {row[5]}")
        print(f"   Cadastrado em: {row[6]}")
        print_separator('-')
    
    conn.close()

def ver_agendamentos():
    """Exibe todos os agendamentos"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM agendamentos')
    total = cursor.fetchone()[0]
    
    print_separator()
    print(f"TODOS OS AGENDAMENTOS (Total: {total})")
    print_separator()
    
    if total == 0:
        print("Nenhum agendamento registrado ainda.")
        conn.close()
        return
    
    cursor.execute('''
        SELECT a.id, c.nome, a.data_agendamento, a.hora_agendamento, 
               a.status, c.endereco_residencial, c.queixa_principal, a.data_criacao
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        ORDER BY a.data_agendamento DESC, a.hora_agendamento DESC
    ''')
    
    for row in cursor.fetchall():
        print(f"\n📅 ID: {row[0]}")
        print(f"   Cliente: {row[1]}")
        print(f"   Data: {row[2]} às {row[3]}")
        print(f"   Status: {row[4]}")
        print(f"   Endereço: {row[5]}")
        print(f"   Queixa: {row[6] if row[6] else 'Não informada'}")
        print(f"   Agendado em: {row[7]}")
        print_separator('-')
    
    conn.close()

def ver_agendamentos_hoje():
    """Exibe agendamentos de hoje"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    hoje = date.today().strftime('%Y-%m-%d')
    
    cursor.execute('''
        SELECT COUNT(*) FROM agendamentos 
        WHERE data_agendamento = ?
    ''', (hoje,))
    total = cursor.fetchone()[0]
    
    print_separator()
    print(f"AGENDAMENTOS DE HOJE ({hoje}) - Total: {total}")
    print_separator()
    
    if total == 0:
        print("Nenhum agendamento para hoje.")
        conn.close()
        return
    
    cursor.execute('''
        SELECT a.hora_agendamento, c.nome, c.endereco_residencial, 
               c.queixa_principal, c.idade
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        WHERE a.data_agendamento = ?
        ORDER BY a.hora_agendamento
    ''', (hoje,))
    
    for row in cursor.fetchall():
        print(f"\n🕐 {row[0]} - {row[1]}")
        print(f"   Idade: {row[4] if row[4] else 'Não informada'}")
        print(f"   Queixa: {row[3] if row[3] else 'Não informada'}")
        print(f"   Endereço: {row[2]}")
        print_separator('-')
    
    conn.close()

def ver_proximos_agendamentos():
    """Exibe próximos agendamentos"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    hoje = date.today().strftime('%Y-%m-%d')
    
    cursor.execute('''
        SELECT COUNT(*) FROM agendamentos 
        WHERE data_agendamento >= ?
    ''', (hoje,))
    total = cursor.fetchone()[0]
    
    print_separator()
    print(f"PRÓXIMOS AGENDAMENTOS (Total: {total})")
    print_separator()
    
    if total == 0:
        print("Nenhum agendamento futuro.")
        conn.close()
        return
    
    cursor.execute('''
        SELECT a.data_agendamento, a.hora_agendamento, c.nome, 
               c.endereco_residencial, a.status
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        WHERE a.data_agendamento >= ?
        ORDER BY a.data_agendamento, a.hora_agendamento
        LIMIT 10
    ''', (hoje,))
    
    for row in cursor.fetchall():
        print(f"\n📅 {row[0]} às {row[1]}")
        print(f"   Cliente: {row[2]}")
        print(f"   Endereço: {row[3]}")
        print(f"   Status: {row[4]}")
        print_separator('-')
    
    conn.close()

def menu():
    """Menu principal"""
    while True:
        print("\n")
        print_separator('=')
        print("SISTEMA DE AGENDAMENTO - VISUALIZAÇÃO DE DADOS")
        print_separator('=')
        print("\nEscolha uma opção:")
        print("1 - Ver todos os clientes")
        print("2 - Ver todos os agendamentos")
        print("3 - Ver agendamentos de hoje")
        print("4 - Ver próximos agendamentos")
        print("0 - Sair")
        print_separator('-')
        
        opcao = input("\nOpção: ").strip()
        
        if opcao == '1':
            ver_clientes()
        elif opcao == '2':
            ver_agendamentos()
        elif opcao == '3':
            ver_agendamentos_hoje()
        elif opcao == '4':
            ver_proximos_agendamentos()
        elif opcao == '0':
            print("\n👋 Até logo!")
            break
        else:
            print("\n❌ Opção inválida!")
        
        input("\nPressione ENTER para continuar...")

if __name__ == '__main__':
    # Verifica se o banco de dados existe
    if not os.path.exists(DB_PATH):
        print(f"❌ Erro: Banco de dados não encontrado em {DB_PATH}")
        print("   Certifique-se de que o sistema foi iniciado pelo menos uma vez.")
        exit(1)
    
    menu()

