#!/bin/bash

# Script de Inicialização do Sistema de Agendamento Quiropraxia
# Execute com: bash iniciar.sh

echo "=========================================="
echo "Sistema de Agendamento - Quiropraxia"
echo "=========================================="
echo ""

# Verifica se está no diretório correto
if [ ! -f "backend/src/main.py" ]; then
    echo "❌ Erro: Execute este script da pasta raiz do projeto"
    echo "   Use: cd /home/ubuntu/quiropraxia_app && bash iniciar.sh"
    exit 1
fi

# Verifica se o ambiente virtual existe
if [ ! -d "backend/venv" ]; then
    echo "⚠️  Ambiente virtual não encontrado. Criando..."
    cd backend
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    cd ..
    echo "✅ Ambiente virtual criado e dependências instaladas"
fi

# Ativa o ambiente virtual
echo "🔧 Ativando ambiente virtual..."
source backend/venv/bin/activate

# Verifica se a porta 5000 está em uso
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "⚠️  Porta 5000 já está em uso"
    echo "   Deseja encerrar o processo existente? (s/n)"
    read -r resposta
    if [ "$resposta" = "s" ] || [ "$resposta" = "S" ]; then
        echo "🛑 Encerrando processo na porta 5000..."
        kill -9 $(lsof -t -i:5000) 2>/dev/null
        sleep 2
    else
        echo "❌ Abortando. Encerre o processo manualmente ou use outra porta."
        exit 1
    fi
fi

# Inicia o servidor
echo ""
echo "🚀 Iniciando servidor Flask..."
echo ""
cd backend
python3 src/main.py

# Nota: O script ficará rodando até você pressionar Ctrl+C

